import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule,
  FormsModule,
  FormGroup,
  FormControl,
  Validators,
  FormBuilder } from '@angular/forms';



@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {
  
myform: FormGroup;
email:FormControl;
password:FormControl;

  constructor() {
   
   }

   ngOnInit() {
    this.createFormControls();
     this.createForm();
  }
  createFormControls() {
  
    this.email = new FormControl("", [
      Validators.required,
      Validators.pattern("[^ @]*@[^ @]*")
    ]);
    this.password = new FormControl("", [
      Validators.required,
      Validators.minLength(8)
    ]);
    }
  
    createForm() {
    this.myform = new FormGroup({
     
      email: this.email,
      password: this.password,
     
    });
  }
  

    onSubmit() {
    if (this.myform.valid) {
      console.log("Form Submitted!");
      console.log(this.myform.value);
     
    }
  }
}